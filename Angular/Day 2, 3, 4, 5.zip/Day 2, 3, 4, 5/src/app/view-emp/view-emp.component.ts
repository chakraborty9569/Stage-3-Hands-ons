import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-emp',
  templateUrl: './view-emp.component.html',
  styleUrls: ['./view-emp.component.css']
})
export class ViewEmpComponent implements OnInit {

  id = '3';
  name = 'John';
  salary = 10000;
  permanent = true;
  department = {id: '1', name: 'Payroll'};
  skills = [{id: '1', name: 'HTML'}, {id: '2', name: 'CSS'}, {id: '3', name: 'JavaScript'}];
  dateOfBirth = new Date('12/31/2000');

  constructor() { }

  ngOnInit(): void {
  }

}
