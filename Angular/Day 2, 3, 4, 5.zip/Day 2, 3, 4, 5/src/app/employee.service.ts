import { Injectable } from '@angular/core';
import { EmployeeComponent } from './employee/employee.component';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employeeList: Array<EmployeeComponent> = [
    {id: '1', name: 'Aman', salary: 10000, permanent: true, department: { id: '1', name: 'Payroll' }, skills: [{ id: '1', name: 'HTML' }, { id: '2', name: 'CSS' }], dateOfBirth: new Date('04/11/1990')},
    {id: '2', name: 'Sunidhi', salary: 20000, permanent: false, department: { id: '2', name: 'Finance' }, skills: [{ id: '2', name: 'CSS' }, { id: '3', name: 'JavaScript' }], dateOfBirth: new Date('04/08/1989')},
    {id: '3', name: 'John', salary: 30000, permanent: true, department: { id: '1', name: 'Payroll' }, skills: [{ id: '1', name: 'HTML' }, { id: '3', name: 'JavaScript' }], dateOfBirth: new Date('03/10/1987')},
    {id: '4', name: 'Karan', salary: 40000, permanent: false, department: { id: '3', name: 'HR' }, skills: [{ id: '1', name: 'HTML' }, { id: '2', name: 'CSS' }], dateOfBirth: new Date('11/11/1991')},
    {id: '5', name: 'Uday', salary: 50000, permanent: true, department: { id: '2', name: 'Finance' }, skills: [{ id: '2', name: 'CSS' }, { id: '3', name: 'JavaScript' }], dateOfBirth: new Date('05/01/1992')}
  ];

  constructor() { }

  getAllEmployees(): EmployeeComponent[]{
    return this.employeeList;
  }

  getEmployee(employeeId){
    for(var i=0; i<this.employeeList.length; i++){
      if(this.employeeList[i].id===employeeId){
        return this.employeeList[i];
      }
    }
  }
}
