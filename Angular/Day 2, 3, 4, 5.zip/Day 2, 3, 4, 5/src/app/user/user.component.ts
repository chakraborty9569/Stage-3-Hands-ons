import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  users : User[];

  constructor(private userService: UserService) { 
    this.userService.getAllUsers().subscribe( (obj: any) => {
      this.users = obj.data;
    });
  }

  ngOnInit(): void {
  }

  createUser(){
    const newUser: User={
      "id" : 13,
      "email" : "sumit.chakraborty@reqres.in",
      "first_name" : "Sumit",
      "last_name" : "Chakraborty",
      "avatar" : "https://reqres.in/img/faces/13-image.jpg"
    };
    this.userService.createUser(newUser).subscribe((newUser: User) => this.users.push(newUser));
  }

  updateUser(){
    const user: User={
      "id" : 14,
      "email" : "sumit.chak@reqres.in",
      "first_name" : "Sumit",
      "last_name" : "C",
      "avatar" : "https://reqres.in/img/faces/14-image.jpg"
    }
    this.userService.updateUser(user).subscribe();
    //console.log("user updated");
  }

  deleteUser(){
    this.userService.deleteUser(13).subscribe();
  }

  register() {
    let invalidUser : User; 
    
    this.userService.register(invalidUser).subscribe();
    console.log("user invalid : ", invalidUser);
  }

}
