import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url="https://reqres.in/api/users?page=2";

  constructor(private httpClient: HttpClient) { }

  getAllUsers() {
    return this.httpClient.get(this.url);
  }

  createUser(user: User){
    return this.httpClient.post(this.url, user);
  }

  updateUser(user: User){
    return this.httpClient.put(this.url, user);
  }

  deleteUser(id: number){
    const url = `${this.url}/${id}`;
    return this.httpClient.delete(url);
  }

  register(invalidUser : User) {
    return this.httpClient.post("https://reqres.in/api/register", invalidUser).pipe(catchError((error:HttpErrorResponse) => {
      return throwError("Error! Register Unsuccessful!");
    }));
  }
}
