import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quantity-increment',
  templateUrl: './quantity-increment.component.html',
  styleUrls: ['./quantity-increment.component.css']
})
export class QuantityIncrementComponent implements OnInit {

  message;
  num = 0;

  /*buttonClick(){
    this.message="Click me bitton clicked!";
  }*/
  add(){
    this.num++;
  }

  subtract(){
    this.num--;
  }

  constructor() { }

  ngOnInit(): void {
  }

}
